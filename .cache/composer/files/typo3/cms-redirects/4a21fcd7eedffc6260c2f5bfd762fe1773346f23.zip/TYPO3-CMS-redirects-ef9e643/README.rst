=============================
TYPO3 extension ``redirects``
=============================

This extension makes it possible to create manual redirects, list existing
redirects and automatically create redirects on slug changes.

:Repository:  https://github.com/typo3/typo3
:Issues:      https://forge.typo3.org/
:Read online: https://docs.typo3.org/c/typo3/cms-redirects/main/en-us/
:Packagist:   https://packagist.org/packages/typo3/cms-redirects
