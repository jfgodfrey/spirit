.. include:: /Includes.rst.txt

..  _start:

===============
TYPO3 Dashboard
===============

:Extension key:
   dashboard

:Package name:
   typo3/cms-dashboard

:Version:
   |release|

:Language:
   en

:Author:
   TYPO3 contributors

:License:
   This document is published under the
   `Open Content License <https://www.openhub.net/licenses/opl>`__.

:Rendered:
   |today|

----

This TYPO3 backend module is used to configure and create backend widgets.

----

**Table of Contents:**

.. toctree::
   :maxdepth: 2
   :titlesonly:

   Introduction/Index
   Installation/Index
   Editor/Index
   Configuration/Index
   Developer/Index
   Widgets/Index
   Migration/Index

.. Meta Menu

.. toctree::
   :hidden:

   Sitemap
