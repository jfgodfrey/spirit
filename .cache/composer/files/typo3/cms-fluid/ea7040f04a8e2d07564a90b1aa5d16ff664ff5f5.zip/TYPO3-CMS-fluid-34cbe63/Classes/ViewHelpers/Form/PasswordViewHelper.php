<?php

declare(strict_types=1);

/*
 * This file is part of the TYPO3 CMS project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License, either version 2
 * of the License, or any later version.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * The TYPO3 project - inspiring people to share!
 */

namespace TYPO3\CMS\Fluid\ViewHelpers\Form;

/**
 * ViewHelper which creates a simple Password Text Box :html:`<input type="password">`.
 *
 * Examples
 * ========
 *
 * Example::
 *
 *    <f:form.password name="myPassword" />
 *
 * Output::
 *
 *    <input type="password" name="myPassword" value="" />
 */
final class PasswordViewHelper extends AbstractFormFieldViewHelper
{
    /**
     * @var string
     */
    protected $tagName = 'input';

    public function initializeArguments(): void
    {
        parent::initializeArguments();
        $this->registerTagAttribute(
            'disabled',
            'string',
            'Specifies that the password field should be disabled when the page loads'
        );
        $this->registerTagAttribute(
            'maxlength',
            'int',
            'The maxlength attribute of the password field (will not be validated)'
        );
        $this->registerTagAttribute('placeholder', 'string', 'The placeholder of the password field');
        $this->registerTagAttribute('readonly', 'string', 'The readonly attribute of the password field');
        $this->registerTagAttribute('autocomplete', 'string', 'Specify the autocomplete behaviour for password managers');
        $this->registerTagAttribute('size', 'int', 'The size of the password field');
        $this->registerArgument(
            'errorClass',
            'string',
            'CSS class to set if there are errors for this ViewHelper',
            false,
            'f3-form-error'
        );
        $this->registerUniversalTagAttributes();
    }

    public function render(): string
    {
        $name = $this->getName();
        $this->registerFieldNameForFormTokenGeneration($name);
        $this->setRespectSubmittedDataValue(true);

        $this->tag->addAttribute('type', 'password');
        $this->tag->addAttribute('name', $name);
        $this->tag->addAttribute('value', $this->getValueAttribute());

        $this->addAdditionalIdentityPropertiesIfNeeded();
        $this->setErrorClassAttribute();

        return $this->tag->render();
    }
}
