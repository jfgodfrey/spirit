=======================
TYPO3 extension ``seo``
=======================

This extension offers special fields for SEO purposes, HTML meta tags display
and sitemaps.

:Repository:  https://github.com/typo3/typo3
:Issues:      https://forge.typo3.org/
:Read online: https://docs.typo3.org/c/typo3/cms-seo/main/en-us/
:Packagist:   https://packagist.org/packages/typo3/cms-seo
