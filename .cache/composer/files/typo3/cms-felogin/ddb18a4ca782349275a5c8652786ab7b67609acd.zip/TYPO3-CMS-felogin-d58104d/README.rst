===========================
TYPO3 extension ``felogin``
===========================

This extension provides a template-based plugin that allows website users to log
in to the TYPO3 frontend.

:Repository:  https://github.com/typo3/typo3
:Issues:      https://forge.typo3.org/
:Read online: https://docs.typo3.org/c/typo3/cms-felogin/main/en-us/
:Packagist:   https://packagist.org/packages/typo3/cms-felogin
