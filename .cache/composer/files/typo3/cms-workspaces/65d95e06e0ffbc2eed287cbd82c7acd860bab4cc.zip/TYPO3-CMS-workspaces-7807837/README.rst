==============================
TYPO3 extension ``workspaces``
==============================

This extension introduces workflows with custom stages and versioning for a more
granular editing and publishing process.

:Repository:  https://github.com/typo3/typo3
:Issues:      https://forge.typo3.org/
:Read online: https://docs.typo3.org/c/typo3/cms-workspaces/main/en-us/
:Packagist:   https://packagist.org/packages/typo3/cms-workspaces
