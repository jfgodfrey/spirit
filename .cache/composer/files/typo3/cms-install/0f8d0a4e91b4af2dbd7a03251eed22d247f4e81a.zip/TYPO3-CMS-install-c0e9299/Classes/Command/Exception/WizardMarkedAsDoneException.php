<?php

declare(strict_types=1);

/*
 * This file is part of the TYPO3 CMS project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License, either version 2
 * of the License, or any later version.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * The TYPO3 project - inspiring people to share!
 */

namespace TYPO3\CMS\Install\Command\Exception;

use TYPO3\CMS\Install\Exception as Typo3InstallException;

/**
 * This exception is thrown in the UpgradeWizardRunCommand, if a requested wizard is already marked as done.
 *
 * @internal for use in UpgradeWizardRunCommand only and not part of public API.
 */
final class WizardMarkedAsDoneException extends Typo3InstallException {}
