<?php
declare(strict_types=1);
namespace Helhum\Typo3Console\Command\Cache;

/*
 * This file is part of the TYPO3 Console project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License, either version 2
 * of the License, or any later version.
 *
 * For the full copyright and license information, please read
 * LICENSE file that was distributed with this source code.
 *
 */

use Helhum\Typo3Console\Service\CacheService;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use TYPO3\CMS\Core\Cache\Exception\NoSuchCacheGroupException;
use TYPO3\CMS\Core\Utility\GeneralUtility;

class CacheFlushTagsCommand extends Command
{
    protected function configure(): void
    {
        $this->setDescription('Flush TYPO3 caches with tags.');
        $this->setHelp('This command can be used to clear the caches with specific tags, for example after code updates in local development and after deployments.');
        $this->setDefinition([
            new InputArgument(
                'tags',
                InputArgument::REQUIRED,
                'Array of tags (specified as comma separated values) to flush.'
            ),
            new InputOption(
                'groups',
                'g',
                InputOption::VALUE_REQUIRED,
                'Array of groups (specified as comma separated values) for which to flush tags. If no group is specified, caches of all groups are flushed.',
                'all'
            ),
        ]);
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $tags = GeneralUtility::trimExplode(',', $input->getArgument('tags'), true);
        if ($input->getOption('groups') !== 'all') {
            $groups = GeneralUtility::trimExplode(',', $input->getOption('groups'), true);
        } else {
            $groups = null;
        }

        try {
            $cacheService = new CacheService();
            $cacheService->flushByTagsAndGroups($tags, $groups);
            if ($groups === null) {
                $output->writeln('Flushed caches by tags "' . implode('","', $tags) . '".');
            } else {
                $output->writeln('Flushed caches by tags "' . implode('","', $tags) . '" in groups: "' . implode('","', $groups) . '".');
            }
        } catch (NoSuchCacheGroupException $e) {
            $output->writeln($e->getMessage());

            return 1;
        }

        return 0;
    }
}
